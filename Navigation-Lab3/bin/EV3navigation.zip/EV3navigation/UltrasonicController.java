package EV3navigation;
// class copied from lab1 
public interface UltrasonicController {
public void processUSData(int distance);
	
	public int readUSDistance();

}
