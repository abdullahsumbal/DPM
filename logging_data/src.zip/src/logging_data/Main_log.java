package logging_data;


import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import lejos.hardware.Button;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3UltrasonicSensor;

public class Main_log{
	static PrintStream writer = System.out;
	
	public static void main (String[] args) throws InterruptedException, FileNotFoundException,UnsupportedEncodingException{
		
		int button_select;
		int array [] = null;
		// initializing the logging
		PrintStream writer = null;
		writer = new PrintStream("data.csv","UTF-8");
		
		//Initializing diplay
		final TextLCD t = LocalEV3.get().getTextLCD();
		//initiazing object for filter class
		Filter filter;
		
		// Initializing the sensor
		EV3UltrasonicSensor sensor = new EV3UltrasonicSensor(SensorPort.S1);
		UltrasonicPoller usPoller= new UltrasonicPoller(sensor.getDistanceMode());
		
		do {
			// clear the display
			t.clear();
			t.drawString("Press left to start", 0, 1);
			t.drawString("Sumbal", 0, 3);
		
		// press button to left button to start  	
		button_select = Button.waitForAnyPress();
		}
		while(button_select != Button.ID_LEFT);
		if(button_select == Button.ID_LEFT)
		{
		
		usPoller.start();
		
		
		try {
			/*
			 * if you want, you can increase the number of sample, 
			 * 
			 */
			int sample=100;
			int distance;
			for(int i =1;i<sample;i++){
				
			distance=usPoller.getDistance();
				
				
				
				//without any filter
				System.out.print(String.format("%d:%d%n",System.currentTimeMillis(),distance));
				writer.println("distance= "+distance);
				
				
				Thread.sleep(100);
			}
			
		} finally  {
			// TODO: handle exception
			writer.close();
			writer.close();
		}
		
	}// end of if condition
		while (Button.waitForAnyPress() != Button.ID_ESCAPE);  
		System.exit(0);
	}
	
	
}
